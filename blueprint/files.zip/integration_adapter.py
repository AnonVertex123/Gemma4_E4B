"""
============================================================
TỰ MINH AGI - INTEGRATION ADAPTER
Kết nối Workflow Orchestrator với các module hiện có
============================================================
"""

import sys
from pathlib import Path
from typing import Dict, List, Any, Optional
import asyncio


class RAGAdapter:
    """
    Adapter cho Cerebro-RAG 2.2
    Wrap các function từ rag_logic.py để phù hợp với interface orchestrator
    """
    
    def __init__(self, rag_logic_module):
        """
        Args:
            rag_logic_module: Module đã import từ rag_logic.py
        """
        self.rag = rag_logic_module
        self.initialized = False
    
    def initialize(self, project_folder: Optional[str] = None):
        """Initialize RAG với project folder"""
        if project_folder:
            # Index project folder nếu chưa index
            self.rag.index_project(project_folder)
        self.initialized = True
    
    def query(self, query: str, project_folder: Optional[str] = None, top_k: int = 5) -> Dict:
        """
        Query RAG database
        
        Args:
            query: Câu hỏi/từ khóa
            project_folder: Folder dự án (optional)
            top_k: Số lượng kết quả trả về
            
        Returns:
            Dict với keys: chunks, sources, scores
        """
        if project_folder and not self.initialized:
            self.initialize(project_folder)
        
        try:
            # Gọi function query từ rag_logic
            results = self.rag.query_knowledge_base(
                query=query,
                top_k=top_k,
                project_folder=project_folder
            )
            
            return {
                "chunks": results.get("documents", []),
                "sources": results.get("metadatas", []),
                "scores": results.get("distances", [])
            }
        
        except Exception as e:
            return {
                "chunks": [],
                "sources": [],
                "scores": [],
                "error": str(e)
            }
    
    def index_folder(self, folder_path: str, file_extensions: List[str] = None) -> Dict:
        """
        Index một folder vào RAG database
        
        Args:
            folder_path: Đường dẫn folder
            file_extensions: Danh sách extension cần index (default: [.py, .js, .md, etc.])
        
        Returns:
            Dict với thông tin indexing
        """
        if file_extensions is None:
            file_extensions = ['.py', '.js', '.md', '.yaml', '.toml', '.txt', '.json']
        
        try:
            result = self.rag.index_project(
                project_folder=folder_path,
                extensions=file_extensions
            )
            
            return {
                "indexed_files": result.get("file_count", 0),
                "total_chunks": result.get("chunk_count", 0),
                "status": "success"
            }
        
        except Exception as e:
            return {
                "indexed_files": 0,
                "total_chunks": 0,
                "status": "failed",
                "error": str(e)
            }


class SearchAdapter:
    """
    Adapter cho Thiên Lý Nhãn 5.2
    Wrap search_logic.py
    """
    
    def __init__(self, search_logic_module):
        """
        Args:
            search_logic_module: Module đã import từ search_logic.py
        """
        self.search = search_logic_module
    
    def search(self, query: str, max_results: int = 5) -> List[Dict]:
        """
        Tìm kiếm trên web
        
        Args:
            query: Từ khóa tìm kiếm
            max_results: Số lượng kết quả
            
        Returns:
            List of search results
        """
        try:
            results = self.search.search_duckduckgo(
                query=query,
                max_results=max_results
            )
            
            return [
                {
                    "title": r.get("title", ""),
                    "url": r.get("link", ""),
                    "snippet": r.get("snippet", "")
                }
                for r in results
            ]
        
        except Exception as e:
            return [{
                "error": str(e),
                "query": query
            }]


class ModelAdapter:
    """
    Adapter cho TuminhAGI_G4 (Gemma 4 E4B)
    """
    
    def __init__(self, model_name: str = "TuminhAGI_G4"):
        """
        Args:
            model_name: Tên model trong Ollama
        """
        self.model_name = model_name
        self.client = None
        
        # Lazy init Ollama client
        try:
            import ollama
            self.client = ollama
        except ImportError:
            print("⚠️  Warning: ollama package not found. Install with: pip install ollama")
    
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4000
    ) -> Dict:
        """
        Generate text từ model
        
        Args:
            prompt: User prompt
            system_prompt: System prompt (optional)
            temperature: Temperature
            max_tokens: Max tokens
            
        Returns:
            Dict với response
        """
        if not self.client:
            return {
                "response": "Error: Ollama client not initialized",
                "error": "ollama package not installed"
            }
        
        try:
            messages = []
            
            if system_prompt:
                messages.append({
                    "role": "system",
                    "content": system_prompt
                })
            
            messages.append({
                "role": "user",
                "content": prompt
            })
            
            response = self.client.chat(
                model=self.model_name,
                messages=messages,
                options={
                    "temperature": temperature,
                    "num_predict": max_tokens
                }
            )
            
            return {
                "response": response["message"]["content"],
                "model": self.model_name,
                "total_duration": response.get("total_duration"),
                "eval_count": response.get("eval_count")
            }
        
        except Exception as e:
            return {
                "response": "",
                "error": str(e)
            }
    
    def generate_with_images(
        self,
        prompt: str,
        images: List[str],
        system_prompt: Optional[str] = None
    ) -> Dict:
        """
        Generate với multimodal (images/audio)
        
        Args:
            prompt: Text prompt
            images: List of image paths hoặc base64
            system_prompt: System prompt
            
        Returns:
            Dict với response
        """
        if not self.client:
            return {"error": "Ollama client not initialized"}
        
        try:
            messages = []
            
            if system_prompt:
                messages.append({
                    "role": "system",
                    "content": system_prompt
                })
            
            messages.append({
                "role": "user",
                "content": prompt,
                "images": images
            })
            
            response = self.client.chat(
                model=self.model_name,
                messages=messages
            )
            
            return {
                "response": response["message"]["content"],
                "model": self.model_name
            }
        
        except Exception as e:
            return {
                "response": "",
                "error": str(e)
            }


class TuminhAGIIntegration:
    """
    Tích hợp toàn bộ hệ thống Tự Minh AGI với Workflow Orchestrator
    """
    
    def __init__(
        self,
        rag_logic_path: str = "./rag_logic.py",
        search_logic_path: str = "./search_logic.py",
        model_name: str = "TuminhAGI_G4"
    ):
        """
        Initialize integration
        
        Args:
            rag_logic_path: Path to rag_logic.py
            search_logic_path: Path to search_logic.py
            model_name: Ollama model name
        """
        # Add paths to sys.path
        for path in [rag_logic_path, search_logic_path]:
            parent = str(Path(path).parent)
            if parent not in sys.path:
                sys.path.insert(0, parent)
        
        # Import modules
        self.rag_adapter = None
        self.search_adapter = None
        self.model_adapter = None
        
        self._load_modules(rag_logic_path, search_logic_path, model_name)
    
    def _load_modules(self, rag_path: str, search_path: str, model_name: str):
        """Load các module"""
        try:
            # Import rag_logic
            import importlib.util
            
            # RAG
            spec = importlib.util.spec_from_file_location("rag_logic", rag_path)
            if spec and spec.loader:
                rag_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(rag_module)
                self.rag_adapter = RAGAdapter(rag_module)
                print("✅ RAG module loaded")
            
            # Search
            spec = importlib.util.spec_from_file_location("search_logic", search_path)
            if spec and spec.loader:
                search_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(search_module)
                self.search_adapter = SearchAdapter(search_module)
                print("✅ Search module loaded")
            
            # Model
            self.model_adapter = ModelAdapter(model_name)
            print(f"✅ Model adapter initialized: {model_name}")
        
        except Exception as e:
            print(f"⚠️  Warning: Could not load all modules: {e}")
    
    def create_orchestrator(self, blueprint_path: str = "./blueprints/task_schema.yaml"):
        """
        Tạo Workflow Orchestrator với các module đã kết nối
        
        Returns:
            WorkflowOrchestrator instance
        """
        from workflow_orchestrator import WorkflowOrchestrator
        
        orchestrator = WorkflowOrchestrator(
            blueprint_path=blueprint_path,
            rag_module=self.rag_adapter,
            search_module=self.search_adapter,
            model_module=self.model_adapter
        )
        
        return orchestrator
    
    async def quick_query(
        self,
        question: str,
        project_folder: Optional[str] = None,
        use_web: bool = True
    ) -> Dict:
        """
        Quick query kết hợp RAG + Web (không dùng workflow)
        
        Args:
            question: Câu hỏi
            project_folder: Folder dự án
            use_web: Có dùng web search không
            
        Returns:
            Dict với answer và sources
        """
        answer_parts = []
        sources = []
        
        # 1. Query RAG
        if self.rag_adapter:
            rag_results = self.rag_adapter.query(question, project_folder)
            if rag_results["chunks"]:
                answer_parts.append("**Từ tri thức nội bộ:**")
                answer_parts.append("\n".join(rag_results["chunks"][:3]))
                sources.extend(rag_results["sources"][:3])
        
        # 2. Query Web (nếu cần)
        if use_web and self.search_adapter:
            web_results = self.search_adapter.search(question, max_results=3)
            if web_results:
                answer_parts.append("\n**Từ internet:**")
                for r in web_results[:3]:
                    if "error" not in r:
                        answer_parts.append(f"- {r['title']}: {r['snippet']}")
                        sources.append(r["url"])
        
        # 3. Tổng hợp với Model
        if self.model_adapter and answer_parts:
            context = "\n\n".join(answer_parts)
            prompt = f"""Dựa trên thông tin sau, hãy trả lời câu hỏi một cách ngắn gọn và chính xác:

**Câu hỏi:** {question}

**Thông tin:**
{context}

**Trả lời:**"""
            
            model_response = self.model_adapter.generate(prompt)
            final_answer = model_response.get("response", "")
        else:
            final_answer = "\n\n".join(answer_parts) if answer_parts else "Không tìm thấy thông tin."
        
        return {
            "answer": final_answer,
            "sources": sources,
            "rag_hits": len(rag_results.get("chunks", [])) if self.rag_adapter else 0,
            "web_hits": len(web_results) if use_web else 0
        }


# ============================================================
# EXAMPLE USAGE
# ============================================================

async def main():
    """Example integration usage"""
    
    # Initialize integration
    integration = TuminhAGIIntegration(
        rag_logic_path="./rag_logic.py",
        search_logic_path="./search_logic.py",
        model_name="TuminhAGI_G4"
    )
    
    # Quick query test
    result = await integration.quick_query(
        question="Làm thế nào để tối ưu RAG?",
        project_folder="./tuminh_agi_project",
        use_web=True
    )
    
    print("=== QUICK QUERY RESULT ===")
    print(f"Answer: {result['answer']}")
    print(f"RAG hits: {result['rag_hits']}")
    print(f"Web hits: {result['web_hits']}")
    print(f"Sources: {result['sources']}")
    
    # Hoặc dùng orchestrator
    orchestrator = integration.create_orchestrator()
    
    execution = await orchestrator.execute_workflow(
        workflow_name="smart_qa",
        inputs={
            "question": "Gemma 4 E4B có những tính năng gì?",
            "project_folder": "./tuminh_agi_project"
        }
    )
    
    stats = orchestrator.get_workflow_stats(execution)
    print("\n=== WORKFLOW STATS ===")
    print(f"Status: {stats['status']}")
    print(f"Completed: {stats['completed_tasks']}/{stats['total_tasks']}")
    print(f"Duration: {stats['total_duration']:.2f}s")


if __name__ == "__main__":
    asyncio.run(main())
